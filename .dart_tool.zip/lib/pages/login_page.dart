import 'package:flutter/material.dart';
import 'package:haaa/calculator/calculator.dart';
import 'package:haaa/constant.dart';
import 'package:haaa/pages/signup_page.dart';
class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);
  @override
  State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  bool showPassword = false;
  bool isLoading = false;

  // Email Validation checker
  final emailPattern =
      r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
  bool validateEmail(String email) {
    final regExp = RegExp(emailPattern);
    return regExp.hasMatch(email);
  }
  // Sign In code
  void login() {
    if (_formKey.currentState!.validate()) {
      isLoading = true;
      setState(() {});
      Future.delayed(const Duration(seconds: 2), () {
        isLoading = false;
        setState(() {});
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => Calculator()),
        );
      });
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text("Login page",style:TextStyle(color: Colors.black) ),
      ),
      body:SingleChildScrollView(
        

       child:Column( 
        
        children: [
       
          Container(
           height: 750,
           
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical:00),
            child: Column(
              children: [
                const SizedBox(height: 20,),
                const Align(
                  alignment: Alignment.topCenter,
                  child: Text(title,style: TextStyle(fontSize: 70, fontWeight: FontWeight.w500,color: Color(0xff233743)),),
                ),
                const SizedBox(height: 40,width: 50,),
                Image.asset(
                  userimage,
                  height: 300,
                ),
                
                //email button
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      const SizedBox(height: 50),
                      TextFormField(
                        controller: _emailController,
                        validator: (value) {
                          if (value!.isEmpty) {
                            return enmail;
                    }
                          //if wrong email entered

                          if (!validateEmail(_emailController.text)) {
                            return valemail;
                          }
                          return null;
                        },


                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                            filled: true,
                            hintText: email,
                            hintStyle: const TextStyle(color: Colors.white),
                            prefixIcon: const Icon(
                              Icons.person,
                              color: Color.fromARGB(255, 125, 240, 3),
                            ),


                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(36.0),
                              borderSide: BorderSide.none,
                            ),
                            fillColor: Color(0xff233743),
                            focusColor: Colors.white),
                      ),
                      
                      //password checker
                      
                      const SizedBox(height: 40),
                      TextFormField(
                        controller: _passwordController,
                        obscureText: showPassword ? false : true,
                        validator: (value) {
                          if (value!.isEmpty) {
                            return enpass;
                          }
                          if (value.length < 8) {
                            return alertpass;
                          }
                          return null;
                        },

                        //password  column
                        style: const TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          filled: true,
                          hintText: pass,
                          hintStyle: const TextStyle(color: Colors.white),
                          prefixIcon: const Icon(
                            Icons.security,
                            color: Color.fromARGB(255, 57, 243, 5)    ,
                          ),
                          suffixIcon: InkWell(
                            onTap: () {
                              setState(() {
                                showPassword = !showPassword;
                              });
                            },
                            child: Icon(
                              showPassword
                                  ? Icons.visibility_off
                                  : Icons.remove_red_eye,
                              color: Colors.white,
                            ),
                          ),
                            //login button
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(36.0),
                            borderSide: BorderSide.none,
                          ),
                          fillColor: Color(0xff233743),
                          focusColor: Colors.white,
                        ),
                      ),
                      const SizedBox(height: 50),
                      InkWell(
                        onTap: () {
                          login();
                        },

                        child: Container(
                          height: 50,
                          decoration: BoxDecoration(
                            color: Color(0xff233743),
                            borderRadius: BorderRadius.circular(36),
                          ),
                          child: Center(
                            child: isLoading
                                ? const Padding(
                                    padding: EdgeInsets.all(8.0),
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                    ),
                                  )
                                : const Text("Login",style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                      fontWeight: FontWeight.w500,
                                    )
                                  ,))),
                          ) ,
                    ]
                  ,)
                  
                )],
        
            ),
          ),
                   SizedBox(height: 100,width: 500,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Text('Don\'t have an account ? ', style: TextStyle(fontSize: 13, color: Color(0xff939393), fontWeight: FontWeight.bold),),
                                GestureDetector(
                                  onTap: () => {
                                    Navigator.push(context, MaterialPageRoute(builder: (context) => const SignupPage()))
                                  },
                                  child: const Text('Sign-up', style: TextStyle(fontSize: 15, color: Color(0xff748288), fontWeight: FontWeight.bold),),
                                ),
                              ],
                            ),
                          )
                          
        ],
      )
                  )              );
  }
}
//home Page


