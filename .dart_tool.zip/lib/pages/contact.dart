class Contact {
  String name;
  String contact;
  String MailID;
  String Officename;
  Contact ({required this.name, required this.contact,required this.MailID,required this.Officename});
}
