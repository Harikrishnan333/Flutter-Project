const String bgimage="image/bg1.webp";
const String userimage="image/user.png";
const String title="User login page";
/*login and password*/
const String enmail="Please Enter Your email";
const String email="Enter your email";
const String valemail="Please Enter Valid Email";
const String pass="Enter your password";
const String enpass="Please Enter Your Password";
const String alertpass="Password must be at least 6 characters";
const String login="Login";
