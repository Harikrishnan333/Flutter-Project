import 'package:flutter/material.dart';
import 'package:haaa/pages/login_page.dart';
import 'constant.dart';
import 'package:firebase_core/firebase_core.dart';


class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginPage(),
    );
  }
}
class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);
  @override
  State<HomePage> createState() => _LoginPageState();
}
class _LoginPageState extends State<HomePage> {

  bool showPassword = false;
  bool isLoading = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      body:SingleChildScrollView(
       child:Column(  
        children: [
          Container(
           height: 1070,
           
            child: Column(
              
              children: <Widget>[
                const SizedBox(height: 100,),
                
                ElevatedButton(onPressed: () {}, child: const Text('Login')),
            ElevatedButton.icon(
              onPressed: (){
                Navigator.push( context,MaterialPageRoute(builder: (context) => const LoginPage()));
              },
              label: const Text('User Display'),
              icon: const Icon(Icons.plus_one),
            ),

                          
         ] ),
                      ),
                      const SizedBox(height: 50),
                      InkWell(
                        onTap: () {
                          login;
                        },

                        child: Container(
                          height: 50,
                          decoration: BoxDecoration(
                            color: Color(0xff233743),
                            borderRadius: BorderRadius.circular(36),
                          ),
                          child: Center(
                            child: isLoading
                                ? const Padding(
                                    padding: EdgeInsets.all(8.0),
                                    child: CircularProgressIndicator(
                                      color: Colors.white,
                                    ),
                                  )
                                  
                                : const Text("Login",style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 18,
                                      fontWeight: FontWeight.w500,
                                    )
                                  ,)
                                  
                                 
                                  )),
                     ) ,
                    ]
                    
                  ) 
                )
            );                                
  }
}
//home Page
